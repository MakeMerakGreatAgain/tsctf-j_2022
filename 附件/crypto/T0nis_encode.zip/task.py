from Crypto.Util.number import *
from secret import flag,key


data=b'abcdefghijkl0123456789'
for i in range(len(key)):
    assert key[i] in data

def T0nihash(a,b):
    if(bytes_to_long(b+a)!=0):
        return long_to_bytes((bytes_to_long(a)*bytes_to_long(a+b))%bytes_to_long(b+a))
    else:
        return b'hahahahaha'

hint=b'thisishint'
cipher=b''
assert flag[0:10]==b'TSCTF-J{Ba'


for i in range(len(flag)//5):
    tmp=flag[5*i:5*i+5]
    if(sum(tmp)%2==0):
        cipher+=long_to_bytes(bytes_to_long(tmp)^bytes_to_long(key[0:5]))
        key=T0nihash(key[0:5],key[5:10])
        hint=T0nihash(hint[0:5], hint[5:10])
    else:
        cipher+=long_to_bytes(bytes_to_long(tmp)^bytes_to_long(key[5:10]))
        key=T0nihash(key[5:10],key[0:5])
        hint=T0nihash(hint[5:10], hint[0:5])

print("cipher =",cipher)
print("hint =",hint)


'''
cipher = b"5asdt\x1d|\xec<\x05\x0e(\x02\xe7\xae\t\xeeq+\x0fq\x0c\xd0\xe5e'\xede\xb38\xca\x90\x1b'\x04pWx\xb1\xc1nk\xdbzmr\xd4^\x95l\xa3L\xb1\x19\xf5v\xe1\xfb\xd5\xa2/\xca\x00\xd9\r\x1d\xf2\xffw\xee\x1a\xf9z\x9dT.\xa1\xee$}"
hint = b'\x01*\xbf=\x80\\1]\xe4'
'''
