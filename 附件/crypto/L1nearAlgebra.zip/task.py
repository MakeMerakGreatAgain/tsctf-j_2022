from sage.all import *
import os

flag = flag + os.urandom(62 - len(flag))
M = Matrix(32,32)
for i in range(32):
        M[i,i] = 2
for i in range(31):
        M[i,i+1] = 1
C = Matrix(32,32)
idx = [i for i in range(1,32)]
for each , i in zip(flag[:31],idx):
    C += each * M ^ i
M = M.transpose()
for each, i in zip(flag[31:],idx):
    C += each * M ^ i
f = open('cipher.txt','w')
f.write(str(list(C)))
f.close()