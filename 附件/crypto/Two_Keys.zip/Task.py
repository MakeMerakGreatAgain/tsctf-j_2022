from Flag import flag1, flag2
from Keys import key, KEY
from Crypto.Util.number import *
from Crypto.Cipher import DES
import hashlib
import gmpy2
import math

Two_Keys = """
████████╗██╗    ██╗ ██████╗     ██╗  ██╗███████╗██╗   ██╗███████╗
╚══██╔══╝██║    ██║██╔═══██╗    ██║ ██╔╝██╔════╝╚██╗ ██╔╝██╔════╝
   ██║   ██║ █╗ ██║██║   ██║    █████╔╝ █████╗   ╚████╔╝ ███████╗
   ██║   ██║███╗██║██║   ██║    ██╔═██╗ ██╔══╝    ╚██╔╝  ╚════██║
   ██║   ╚███╔███╔╝╚██████╔╝    ██║  ██╗███████╗   ██║   ███████║
   ╚═╝    ╚══╝╚══╝  ╚═════╝     ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝                                                                     
"""
print(Two_Keys)

print("Chaoyue has two Keys in hand, one is called key and the other is called KEY.\n")

print("Here are two Questions, key is the answer of Question 1 and KEY is the answer of Question 2.\n")

print("Question 1:\n\nHere is a grid of 11 * 11, The key is the total number of paths from A to B, but you cannot cross the line between A and B")

picture = """
┌——┬——┬——┬——┬——┬——┬——┬——┬——┬——B
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
├——┼——┼——┼——┼——┼——┼——┼——┼——┼——┤
A——┴——┴——┴——┴——┴——┴——┴——┴——┴——┘
"""

print(picture)

print("Question 2:\n\nKEY is a string of 8 lowercase letter.\n\nsha256(KEY) == 2b87ea3983c646fcecc476f6930c18bf75935cab40471930f560bef2f370b82e and len(KEY) == 8\n")

while True:
    p = getPrime(1024)
    q = getPrime(1024)
    n = p * q
    phi = (p - 1) * (q - 1)
    e = key // 2
    if math.gcd(e, phi) == 1:
        d = gmpy2.invert(e, phi)
        break

message1 = bytes_to_long(flag1)
cipher1 = gmpy2.powmod(message1, e, n)

# print("p = ", hex(p))
# print("q = ", hex(q))
# print("n = ", hex(n))
# print("phi = ", hex(phi))
# print("cipher1 = ", hex(cipher1))

"""
p = 0xb35c9cff71660f5b9d56b10956a3ae52ae547914d4bfbd801bd08e4a95f0e80fb40224a266c3adf45cdd6327c3b01c269692557e412a8e3e2f4370aa3acaf7cffa48010a8cc333862336e85d7ff5387ab503cc9ece97608587884ddc6ca4cd52477abc44168415f92746566f07ab38877d21a03d8b95e4e4f4d58a56614bf879
q = 0xaefd1ce2dfee9240867bb8cace347dcabe974219232206be850202f37771d9876434595f9562b796a5848b0fa2f2fbcc7b987bb6f003c65c2708a7aca8db4536f9040ae5b8bf68a392835affc003fdd111584662907514de01b430e4789b15dffbb9cd8875832a8f4fdb34cbc4bae7b52df68c8e016c15c3f8b7697c0420f829
n = 0x7a9a4979dd59cd8b38706b0920ffc1d63ee9c6c94cc6bf097c0957d5017b6562d7b03f396b9cd1f9e6a7303522effe632422c44360c66fe8526ff997db1496f2c1a70ab179f59f5fc4b1dd5513cc663d811b50e1c2b29dfa1ae5228b1fd2b7b65595c4486eb3d22fbd2b6fba58b4f299f07a73fc90e97af9781156afb0af32a02a4a1198b734fa2fefdfd64d2767e095db30919a6cbf3de0217f949d9b46e704a3cefe3af62fdfdd702e439ef423e7582d6b67903a1c956d1d7f3a62baa217f2c47d81c08f9734eb19f13c9bcd3d55c098498af02aa4dc5449668682a150050675d0b74e9dfb2698031dcbd726da450c62f48a4b24ab2da2d8bd2b1421000361
phi = 0x7a9a4979dd59cd8b38706b0920ffc1d63ee9c6c94cc6bf097c0957d5017b6562d7b03f396b9cd1f9e6a7303522effe632422c44360c66fe8526ff997db1496f2c1a70ab179f59f5fc4b1dd5513cc663d811b50e1c2b29dfa1ae5228b1fd2b7b65595c4486eb3d22fbd2b6fba58b4f299f07a73fc90e97af9781156afb0af329ec7f057b665e05893cc0d6c79028fb4786e44d66c74dd79a180ad035f8de4256d8b988038fa097a526dcc55678d80cf651b40965b08ee40d2c733220bd6fbdaebd13175d04a1498c16436f93e8d441f74d1ed77eecb9866f0c02a07c1bc1021d4329c2d8211f3e60f8bfc409c5a7424cfb7dc5d7f97a932f9eb303741bb9312c0
cipher1 = 0x57765d8a8d0d74a3f6e3151cc1276b8db6e790d691f7d06713c1d5791164902f6add5a4350512225034d114ae59603a431d1b8ebc956bdc30a3d69cc364649dada23153483bfbf1cfb06ffb22ca9e969674d68a2dae6c9482dfe7b95561035396996473d37cdae2c7e6bda62face36d487d31810cad3382a37c881ea694eb45b4a1788eb1f7865ff3105a3669e7bf39bb0e04d46b98acbfefbdebeb3c2e967e1db553420337db750805d08483760f7abb9ad69d4fc489ec3c2cc9c10778fe03090b8b0b33854047aafab676c4a2a4d6b94b4df6e2ed6f23d9ba6e8713cbeeb5aab5bbf23558afade67460d2561f0a60a26a8c064550eb858b8e25fcf72bcb581
"""

# 密钥KEY的长度为8
assert len(KEY) == 8

# 获取KEY的sha256哈希值
sha256_of_KEY = hashlib.sha256(KEY.encode()).hexdigest()

# print("sha256_of_KEY = ", sha256_of_KEY)

"""
sha256_of_KEY = 2b87ea3983c646fcecc476f6930c18bf75935cab40471930f560bef2f370b82e
"""

# 工作模式为ECB模式
generator = DES.new(KEY.encode(), DES.MODE_ECB)

# 非8整数倍长度明文补位,填充方式为PKCS7
padding_len = 8 - len(flag2) % 8
padding_str = ""
for i in range(padding_len):
    padding_str += chr(padding_len)

message2 = (flag2 + padding_str).encode()
cipher2 = generator.encrypt(message2)

# print("cipher2 = ", cipher2)

"""
cipher2 = b'\x83\xce\x8a\xdac)\xd2\xa41\xe26\xd5\x12\xcf\x9aV;%\x80\xc1\x87\x97\xe0\xc3\x03\x17\xfeR\x97b\x86\xf9"\x1c\xde\xf4\xc1F\xd5\x13\x1e$\xc3\xb8\x84Z}\xac'
"""
