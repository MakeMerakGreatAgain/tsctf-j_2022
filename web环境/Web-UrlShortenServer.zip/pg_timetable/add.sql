DO $do$
BEGIN
	IF NOT EXISTS (SELECT FROM timetable.chain where chain_name = 'refresh') THEN
		PERFORM timetable.add_job('refresh', '@every 30 minutes', 'TRUNCATE public.url_info, public.url_info RESTART IDENTITY');
	END IF;
END $do$