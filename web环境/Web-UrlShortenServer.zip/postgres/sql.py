import random
import string

f = open('init.sql', 'wb')

rand_table = []

def generate_100_random():
    res = []
    while 1:
        value = ''.join(random.sample(string.ascii_letters + string.digits + '_', 14))
        if value not in res:
            res.append(value)
            if len(res) == 100:
                break
        else:
            continue
    return res

head = '''CREATE user bupt_ctfer with password 'bupt_is_bad_bad';
CREATE DATABASE url_shorter with OWNER bupt_ctfer;
\c url_shorter bupt_ctfer;
DROP TABLE IF EXISTS url_info;
CREATE TABLE url_info  (
  id serial NOT NULL,
  long_url varchar(511) NOT NULL,
  query_para varchar(511) NOT NULL,
  verify_id varchar(511) NOT NULL,
  mur_hash_code varchar(255) NOT NULL CHECK(length(mur_hash_code)>4),
  insert_at varchar(255) NOT NULL,
  latest_visit_at varchar(255) NOT NULL,
  visit_count INTEGER NOT NULL DEFAULT 0,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
	UNIQUE(mur_hash_code)
);
'''.encode()

f.write(head)

list = generate_100_random()

for uuid in list:
    rand = f'''DROP TABLE IF EXISTS "{uuid}";
CREATE TABLE "{uuid}"  (
id serial NOT NULL,
name INTEGER NOT NULL
);
'''.encode()
    f.write(rand)

flag = '''DROP TABLE IF EXISTS tH3re_1s_fl4gg;
CREATE TABLE tH3re_1s_fl4gg  (
  id serial NOT NULL,
  fflagg varchar(255) NOT NULL
);
INSERT INTO tH3re_1s_fl4gg(fflagg) VALUES($$TSCTF-J{R3Mem6eR_Th4t_Jv5T_L3@rn_f0R_FuN}$$);
'''.encode()

f.write(flag)

f.close()
