# NOTICE
files 
`blockly_compressed.js`
`blocks_compressed.js`
`javascript_compressed.js`
`zh-hans.js`
`media/*` 
copyed from  
https://github.com/google/blockly.git

`Converter.bundle.min.js`  
copyed from  
https://github.com/zhaouv/antlr-blockly.git