main.floors.TheLost=
{
    "floorId": "TheLost",
    "title": "珠珠走丢之地",
    "name": "?",
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": true,
    "defaultGround": "ground3",
    "images": [],
    "ratio": 1,
    "map": [
    [  2,  2,  2,  2,300,300,300,300,300,  2,  2,  2,  2],
    [  2,311,311,311,  6,  6,  6,  6,  6,311,311,311,  2],
    [  2,311,311,  0,  0,  0,  0,  0,  0,  0,311,311,  2],
    [  2,311,  0,  0,  0,  0,  0,  0,  0,  0,  0,311,  2],
    [300,  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,300],
    [300,  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,300],
    [300,  6,  0,  0,  0,  0, 81,  0,  0,  0,  0,  6,300],
    [300,  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,300],
    [300,  6,  0,  0,  0,  0,  0,  0,  0,  0,  0,  6,300],
    [  2,311,  0,  0,  0,  0,  0,  0,  0,  0,  0,311,  2],
    [  2,311,311,  0,  0,  0,  0,  0,  0,  0,311,311,  2],
    [  2,311,311,311,  6,  6,  6,  6,  6,311,311,311,  2],
    [  2,  2,  2,  2,300,300,300,300,300,  2,  2,  2,  2]
],
    "firstArrive": [
        "\t[DZ,hero]\b[hero]你好\\d${flag：input}\\d，我是DZ。我的小马珠珠走丢了，但在昨天晚上的梦境中，神明告诉了我它的线索",
        {
            "type": "screenFlash",
            "color": [
                0,
                0,
                0
            ],
            "time": 2000,
            "times": 1,
            "async": true
        },
        {
            "type": "changeFloor",
            "floorId": "CyberLT",
            "time": 500
        },
        {
            "type": "waitAsync"
        }
    ],
    "parallelDo": "",
    "events": {},
    "changeFloor": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [

],
    "fgmap": [

],
    "width": 13,
    "height": 13,
    "autoEvent": {
        "6,8": {
            "0": null,
            "1": null,
            "2": null
        }
    },
    "beforeBattle": {},
    "eachArrive": [
        {
            "type": "changePos",
            "loc": [
                6,
                8
            ],
            "direction": "up"
        }
    ]
}