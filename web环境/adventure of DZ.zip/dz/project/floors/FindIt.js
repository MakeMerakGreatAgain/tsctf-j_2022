main.floors.FindIt=
{
    "floorId": "FindIt",
    "title": "锐科省",
    "name": "?",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "grass2",
    "firstArrive": [
        {
            "type": "changePos",
            "loc": [
                6,
                12
            ],
            "direction": "up"
        },
        "建议存个档，不存也行，反正没开自动存档",
        {
            "type": "callSave"
        },
        {
            "type": "moveHero",
            "time": 200,
            "steps": [
                "up:10"
            ]
        },
        {
            "type": "moveHero",
            "time": 200,
            "steps": [
                "right:1"
            ]
        },
        {
            "type": "sleep",
            "time": 500
        },
        {
            "type": "playBgm",
            "name": "secret-base.mp3",
            "keep": true
        },
        {
            "type": "setVolume",
            "value": 20,
            "time": 0
        },
        "小马...找到你了！",
        {
            "type": "screenFlash",
            "color": [
                255,
                255,
                255,
                1
            ],
            "time": 1000,
            "times": 2
        },
        "\t[小马珠珠]#￥%#￥%#……￥%……#￥%……￥",
        {
            "type": "if",
            "condition": "flag:input",
            "true": [
                "\t[DZ,hero]...${flag:input}，有个不太好的消息"
            ],
            "false": [
                "\t[DZ,hero]...哥们儿，有个不太好的消息"
            ]
        },
        "\t[Player,blueKing]细🔒",
        "\t[DZ,hero]刚刚珠珠跟我说，它在回家途中溜大了，把旗子丢到某个地方了",
        "\t[Player,blueKing]...",
        "\t[Player,blueKing]😁😁😁",
        "\t[Player,blueKing]这真是你的小马珠珠？会不会认错了，让我测你的马",
        "\t[DZ,hero]别急别急，你先别急。珠珠说在我们来的路上已经有线索了，要不...你remake去重新看看？",
        "\t[Player,blueKing]😅😅😅谔谔",
        "\t[Player,blueKing]咋说你也给点线索吧，别真remake一次啊",
        "\t[DZ,hero]那就...\r[red]你会看英文缩写么\r...",
        "\t[DZ,hero]言尽于此，什么都不知道了。珠珠挂五档，走了！",
        {
            "type": "screenFlash",
            "color": [
                255,
                255,
                255,
                1
            ],
            "time": 1000,
            "times": 2
        },
        {
            "type": "setHeroIcon",
            "name": "flo.png"
        },
        {
            "type": "unfollow"
        },
        {
            "type": "function",
            "function": "function(){\nif(flags.input != ''){core.status.hero.name = flags.input;}else{core.status.hero.name = 'Player';} core.updateStatusBar()\n}"
        },
        "然后这游戏到这儿就完了，知道为啥前面要喊你存档了吧",
        "没存？没存我就含泪开香槟了😄",
        {
            "type": "callLoad"
        }
    ],
    "eachArrive": [
        "欢迎使用事件编辑器(回车直接多行编辑)"
    ],
    "parallelDo": "",
    "events": {},
    "changeFloor": {},
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "map": [
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0, 90,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,  0,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308],
    [308,308,308,  0,  0,  0,  0,  0,  0,  0,308,308,308]
],
    "bgmap": [
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,300,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,300,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,300,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0],
    [  0,  0,  0,311,300,300,  6,300,300,311,  0,  0,  0]
],
    "fgmap": [

],
    "cannotMoveDirectly": false
}