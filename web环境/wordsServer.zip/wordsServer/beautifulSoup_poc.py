from bs4 import BeautifulSoup
import requests
url='http://49.232.201.163:46128'
data=[]

text=requests.get(url).text
soup = BeautifulSoup(text, "html.parser")

divArray = soup.find_all('div', {"class":"chunk"})
for div in divArray:
    data.append({
        'id':div['id'],
        'answer':div.find("p",{"class":"en"}).text
    })
print(requests.post(url+'/submit',json=data).text)
