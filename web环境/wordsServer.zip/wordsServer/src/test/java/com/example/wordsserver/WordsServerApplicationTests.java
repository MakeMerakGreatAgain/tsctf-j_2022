package com.example.wordsserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordsServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
