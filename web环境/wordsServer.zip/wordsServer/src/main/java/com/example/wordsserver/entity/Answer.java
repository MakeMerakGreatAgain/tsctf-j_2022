package com.example.wordsserver.entity;

import java.io.Serializable;

public class Answer implements Serializable {
    public String answer;
    public int id;
}
