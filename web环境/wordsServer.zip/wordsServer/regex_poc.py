import requests
import re
url='http://49.232.201.163:46128'

idPattern=r'<div id="(\d+)?" class="chunk" style=" width: 30%;margin: 25px auto;text-align: left;">'
answerPattern=r'<p class="en" style="visibility:hidden;display: inline">(\w+)</p>'

text=requests.get(url).text
idArray=re.findall(idPattern,text)
answerArray=re.findall(answerPattern,text)

assert(len(idArray)==len(answerArray))

data=[]
for i in range(len(idArray)):
    data.append({'id':idArray[i],'answer':answerArray[i]})
print(requests.post(url+'/submit',json=data).text)