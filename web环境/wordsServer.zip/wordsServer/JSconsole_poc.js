const divArray=document.getElementsByClassName('chunk')
for(div of divArray){
    const en=div.getElementsByClassName('en')[0].innerHTML
    div.getElementsByTagName('input')[0].value=en
}
submit()