module.exports={
    'jwtSecret':process.env.jwtSecret,
    'port':3000,
    'mongoDBpath':process.env.MONGODB_PATH,
    'flagUserId':process.env.flagUserId,
    'flag':process.env.FLAG,
    'flagUserPassword':process.env.flagUserPassword,
    // 《邶风·击鼓》
    'defaultQuestion':'死生契阔，与子成说。执子之手，与子偕老。'
}
