<?php
include("class.php");
if(is_array($_GET['a']) || is_array($_GET['b']))
    echo("die");
else
{
    if(md5($_GET['a'])===md5($_GET['b']) && $_GET['a']!=$_GET['b'])
        unserialize($_GET['pop']);
    else 
        echo("nonono!");
}