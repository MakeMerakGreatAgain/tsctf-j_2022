<?php
$hint="flag is in the root directory;";
?>