<?php
header('content-type:text/html;charset=utf-8');
$kb=base64_encode(base64_encode("https://api.mtyqx.cn/tapi/random.php"));
if(!isset($_GET['f']))
    header('Refresh: 0;url=./index.php?f='.$kb);
$fname=base64_decode(base64_decode($_GET['f']));
if(preg_match('/f|index.php|hint.php/i',$fname))
{
    $fname="https://img.paulzzh.tech/touhou/random";
    $src="data:image/gif;base64,".base64_encode(file_get_contents($fname));
    echo "<img src={$src} />";
    die("no,you can't see this.can can class.php and hack.php.");
}
$src="data:image/gif;base64,".base64_encode(file_get_contents($fname));
echo "<img src={$src} />";
?>
<html>
    <style>
        body{
            background-size:cover;
            background-attachment:fixed;
            background-color:#CCCCCC;
        }
    </style>
    <body>
    </body>
</html>