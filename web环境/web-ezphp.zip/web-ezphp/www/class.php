<?php
class apple
{
    public $var;
    public $m1;
    public function __wakeup()
    {
        echo $this->var."1!5!";
    }
    public function __call($name, $args)
    {
        return $this->m1->$source;
    }
}
class banana
{
    public $str;
    public $v1;
    public function __toString()
    {
        $function=$this->str;
        $function();
    }
    public function __invoke()
    {
        return $this->v1->hack();
    }
}
class find
{
    protected $code;
    public function __get($name)
    {
        $this->backdoor();
    }
    public function backdoor()
    {
        if(';' === preg_replace('/[^\W]+\((?R)?\)/', '', $this->code)) 
            if(!preg_match('/et|info|dec|bin|hex|oct|pi|log/i',$this->code))
                @eval($this->code);
    }
}
?>